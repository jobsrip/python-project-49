# Starting brain-progression

from brain_games.architecture.engine import run_game
from brain_games.games import game_progression

def main():
    run_game(game_progression)


if __name__ == '__main__':
    main()