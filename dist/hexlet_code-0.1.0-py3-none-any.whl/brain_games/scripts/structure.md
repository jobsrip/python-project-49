


                            Architecture of all games

1) Greet 
     Hello, what is your name? > Name
     Welcome to the games 'Name'!


2) Question
    What is the result of this action? 
    Action
    Your answer > Answer


3) Compare
    Comparison of the user answer and the correct answer


4) Continue or break
    if result True 
        Continue
    if result False
        Sorry 'Name', let's try again!





