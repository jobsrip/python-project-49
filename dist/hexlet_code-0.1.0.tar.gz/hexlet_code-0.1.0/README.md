### Hexlet tests and linter status:
[![Actions Status](https://github.com/jobsrip/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/jobsrip/python-project-49/actions)
<a href="https://codeclimate.com/github/jobsrip/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2e8e6d60fe9584926578/maintainability" /></a>
brain-even: https://asciinema.org/a/590022
brain-calc: https://asciinema.org/a/590040