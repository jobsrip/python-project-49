### Hexlet tests and linter status:
[![Actions Status](https://github.com/jobsrip/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/jobsrip/python-project-49/actions)
<a href="https://codeclimate.com/github/jobsrip/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/2e8e6d60fe9584926578/maintainability" /></a>




Asciinema recs:

brain-even: https://asciinema.org/a/590022
brain-calc: https://asciinema.org/a/xqHklnmDMjNFodW6o9uVG3nbv
brain-gcd: https://asciinema.org/a/OL3F8o92z9Xz387wPsXbmUFzm
brain-progression: https://asciinema.org/a/rbVhdk50KMnLPmLVS87DfAu5X