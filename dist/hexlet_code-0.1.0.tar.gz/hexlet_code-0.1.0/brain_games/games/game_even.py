from brain_games.engine import my_function

def main():
    my_function


main

#if __name__ == '__main__':
   # main()
    